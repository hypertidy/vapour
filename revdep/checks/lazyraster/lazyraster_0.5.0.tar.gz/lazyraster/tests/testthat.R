library(testthat)
library(lazyraster)

test_check("lazyraster")
